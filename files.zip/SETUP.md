# Setup Guide — Run Sheet Generator

This guide walks you through everything needed to get the Phase 1 build running on Vercel with real PDF extraction.

> **Time estimate**: 1–2 hours for first-time setup, mostly waiting for things to provision. Most steps are one-time.

---

## Order of operations

Do these in order. Each step depends on the previous one.

1. Wipe the broken repo and push the new code
2. Set up Anthropic (Claude API)
3. Set up Google Cloud Document AI
4. Configure Vercel environment variables
5. Deploy and test

---

## Step 1 — Repo cleanup and push

### 1.1 Wipe the existing repo

Go to https://github.com/BOPABSTRACT/Run-Sheet-Generator. **Delete every file** in the repo. The cleanest way:

- Click each file → click the trash can icon → commit
- OR use the GitHub web UI to delete the entire repo and recreate it with the same name

The existing files are all broken (wrong casing, no working code, see `BUILD_PLAN.md` section 6). They must go.

### 1.2 Add the new files

Upload the entire contents of the `runsheet-build/` folder (everything you got from this session) to the root of the repo. Either:

- **Web UI**: Drag and drop folders into GitHub
- **Git CLI**: 
  ```
  git clone https://github.com/BOPABSTRACT/Run-Sheet-Generator
  # delete old contents, copy new contents in
  git add -A
  git commit -m "Phase 1 clean rebuild"
  git push
  ```

Make sure the file structure looks like this on GitHub:

```
Run-Sheet-Generator/
├── app/
│   ├── api/
│   │   ├── extract/route.ts
│   │   └── health/route.ts
│   ├── layout.tsx
│   └── page.tsx
├── lib/
│   ├── docai.ts
│   └── claude.ts
├── public/
├── docs/
│   ├── BUILD_PLAN.md
│   └── SETUP.md   (this file)
├── .gitignore
├── next.config.js
├── package.json
├── tsconfig.json
└── README.md
```

**Lowercase filenames matter.** Do not rename anything to capital letters.

### 1.3 Verify Vercel auto-deploys

Go to https://vercel.com/dashboard → your `run-sheet-generator` project. After your push, Vercel should automatically start a new build. It will probably **fail at first** because the environment variables aren't set yet. That's expected. Continue with Steps 2–4 below.

---

## Step 2 — Anthropic API key

### 2.1 Create account and add billing

1. Go to https://console.anthropic.com
2. Sign up or log in
3. Go to **Settings → Billing** and add a payment method
4. **IMPORTANT: Set a monthly spending limit.** Start with $25/month so you can't get surprise-billed during testing. You can raise it later.

### 2.2 Generate an API key

1. Go to **Settings → API Keys**
2. Click **Create Key**
3. Name it something like "run-sheet-generator-prod"
4. **Copy the key immediately** — it starts with `sk-ant-...` — Anthropic only shows it once
5. Save it somewhere safe (password manager) — you'll paste it into Vercel in Step 4

### Cost expectations
For the volume you're describing (1000 runsheets/week, ~10 documents per runsheet, ~5 pages per doc):
- Roughly $0.01–$0.03 per document = ~$100–$300/month for the LLM extraction
- Set monthly limit to $500 once you go to production to be safe

---

## Step 3 — Google Cloud Document AI

This is the longest step. Go slowly, and don't worry if it takes 30–45 minutes the first time.

### 3.1 Create a Google Cloud account and project

1. Go to https://console.cloud.google.com
2. Sign in with a Google account (use a business account, not personal Gmail)
3. **New users get $300 free credit** for 90 days — plenty for testing
4. Click the project dropdown at the top → **New Project**
5. Name it `bop-runsheet-generator` or similar
6. Note the **Project ID** (it looks like `bop-runsheet-generator-12345`) — you'll need this later

### 3.2 Enable billing

Even with free credit, you must add a billing account:
1. Left sidebar → **Billing**
2. Link a payment method
3. Free credits cover this — you won't actually be charged for normal testing

### 3.3 Enable the Document AI API

1. In the search bar at the top of the console, type "Document AI"
2. Click **Document AI API**
3. Click **Enable**
4. Wait for it to finish (30 seconds)

### 3.4 Create a Document AI processor

1. Left sidebar → **Document AI** (or search "Document AI" again)
2. Click **Processors** → **Create Processor**
3. Choose **Document OCR** processor for now (we'll evaluate Layout Parser later if needed)
4. Region: **United States (us)**
5. Name: `runsheet-ocr-processor`
6. Click **Create**
7. After creation, **copy the Processor ID** from the processor's detail page — looks like a long string of letters/numbers

You now have:
- **Project ID**: e.g., `bop-runsheet-generator-12345`
- **Processor ID**: e.g., `a1b2c3d4e5f6g7h8`
- **Location**: `us`

### 3.5 Create a service account

1. Left sidebar → **IAM & Admin → Service Accounts**
2. Click **Create Service Account**
3. Name: `runsheet-docai-sa`
4. Click **Create and Continue**
5. Grant role: **Document AI API User**  
   (search "Document AI" in the role dropdown)
6. Click **Continue** → **Done**

### 3.6 Generate a service account key

1. Click on the service account you just created
2. Go to the **Keys** tab
3. **Add Key → Create new key → JSON → Create**
4. A JSON file downloads automatically. **Keep this file secret.** Never commit it to GitHub.
5. Open the file in a text editor — you'll need its contents in the next step.

### 3.7 Base64-encode the service account key

We need to put the JSON file's contents into a Vercel environment variable. The cleanest way is to base64-encode it.

**On macOS / Linux:**
```bash
base64 -i path/to/your-key.json | tr -d '\n'
```

**On Windows (PowerShell):**
```powershell
[Convert]::ToBase64String([IO.File]::ReadAllBytes("path\to\your-key.json"))
```

Copy the resulting long string (no line breaks). You'll paste it into Vercel as `GOOGLE_SERVICE_ACCOUNT_KEY_BASE64`.

### Cost expectations
- Document AI OCR: ~$1.50 per 1,000 pages
- For 1,000 runsheets/week × ~50 pages avg = 50,000 pages/week = ~$300/month
- Plus the free $300 credit covers your first ~3 months entirely

---

## Step 4 — Vercel environment variables

1. Go to https://vercel.com/dashboard → your `run-sheet-generator` project
2. **Settings → Environment Variables**
3. Add the following (set Environment to "Production, Preview, Development" for all):

| Name | Value |
|---|---|
| `ANTHROPIC_API_KEY` | The `sk-ant-...` key from Step 2 |
| `GOOGLE_CLOUD_PROJECT_ID` | The project ID from Step 3.1 |
| `GOOGLE_DOCAI_PROCESSOR_ID` | The processor ID from Step 3.4 |
| `GOOGLE_DOCAI_LOCATION` | `us` |
| `GOOGLE_SERVICE_ACCOUNT_KEY_BASE64` | The long base64 string from Step 3.7 |

4. **Optional but recommended**: enable Vercel Blob storage
   - Project → **Storage** → **Create Database** → **Blob**
   - This auto-sets `BLOB_READ_WRITE_TOKEN`

### 4.1 Redeploy

After adding env vars:
1. Go to **Deployments** tab
2. Click the three-dot menu on the latest deployment → **Redeploy**

The build should now succeed.

---

## Step 5 — Test it

1. Go to https://run-sheet-generator.vercel.app
2. Fill in the form fields (Abstractor Name, Property Description, etc.)
3. Click **Choose Files** and upload `DB_1094-697.pdf` (the modern typed deed)
4. Click **Generate with Real Data**
5. Watch for results

### What you should see (Phase 1 acceptance criteria)
- A loading state for ~10–30 seconds while OCR + Claude processing happens
- An editable table appearing with 1 row of extracted instrument data
- Fields populated with: VOL/PAGE = "DB 1094/697", Instrument Type = "General Warranty Deed", Doc. Date / Recorded Date = "2/13/1996", Grantor = "Archie Freeland, Jr.", Grantee = "Monongahela Power Company", etc.
- An "Export to Excel" button that downloads a .xlsx in your runsheet format

### If it doesn't work — debugging
1. Open browser DevTools (F12) → Console tab → look for red errors
2. Vercel dashboard → **Logs** tab → click the failed function → read the error
3. Most common Phase 1 issues:
   - Missing env var (check spelling exactly — case matters)
   - Service account doesn't have Document AI API User role
   - File too large (Vercel default body limit is 4.5MB — we handle this in code but verify your test PDF is under that)
   - Anthropic spending limit hit (check console.anthropic.com → Usage)

---

## After Phase 1 works

Once you have a working extraction → review → export flow:

1. Test it on a real production runsheet, side by side with your normal workflow
2. Time how long it takes vs. the normal manual process
3. **If it saves real time**: this validates the project. Consider hiring a software engineer for Phase 2+.
4. **If it doesn't yet**: the next session with Claude should focus on prompt tuning for extraction accuracy.

---

## Rollback

If something goes seriously wrong with the deployed app and you want to roll back:

1. Vercel dashboard → **Deployments**
2. Find the last working deployment
3. Three-dot menu → **Promote to Production**

This is instant. Don't delete the broken deployment — keep it for debugging.
